// offtarget-merge — Cross-sample off-target genomic region consensus finder.
//
// Usage examples:
//
//   # Typical run — 80 % consensus, MAPQ >= 20, 500 bp gap tolerance
//   offtarget-merge \
//     --input-pattern "data/*_BQSR_bam_off_model*.tsv" \
//     --mapq-min 20 \
//     --gap-tolerance 500 \
//     --threshold 0.8 \
//     --output consensus_regions.csv
//
//   # Strict: all samples, MAPQ >= 30, verbose per-file stats
//   offtarget-merge -i "samples/*.tsv" -q 30 -t 1.0 -v -o strict.csv
//
//   # Permissive: include MAPQ=0 reads, 60 % of samples required
//   offtarget-merge -i "samples/*.tsv" -q 0 -t 0.6 --min-reads 3 -o permissive.csv
//
// Output CSV columns:
//   chrom, region_start, region_end, region_width_bp,
//   sample_count, sample_fraction, contributing_samples

mod args;
mod merger;
mod output;
mod reader;
mod sweep;

use std::collections::BTreeMap;
use std::path::{Path, PathBuf};
use std::time::Instant;

use clap::Parser;
use indicatif::{ProgressBar, ProgressStyle};
use rayon::prelude::*;

use args::Args;
use merger::{merge_intervals, MergedRegion};
use sweep::find_consensus;

fn main() -> anyhow::Result<()> {
    let args = Args::parse();

    // ── Validate arguments ──────────────────────────────────────────────────
    if args.threshold < 0.0 || args.threshold > 1.0 {
        eprintln!("Error: --threshold must be between 0.0 and 1.0");
        std::process::exit(1);
    }

    // ── Resolve input files from glob pattern ───────────────────────────────
    let input_files: Vec<PathBuf> = glob::glob(&args.input_pattern)
        .unwrap_or_else(|e| {
            eprintln!("Error: invalid glob pattern '{}': {}", &args.input_pattern, e);
            std::process::exit(1);
        })
        .filter_map(|entry| match entry {
            Ok(p)  => Some(p),
            Err(e) => { eprintln!("[warn] glob error: {}", e); None }
        })
        .filter(|p| p.is_file())
        .collect();

    if input_files.is_empty() {
        eprintln!(
            "Error: no files matched pattern '{}'.\n\
             Check that the path and wildcard are correct.",
            &args.input_pattern
        );
        std::process::exit(1);
    }

    let total_files = input_files.len();
    println!(
        "offtarget-merge v{} — {} file(s) matched",
        env!("CARGO_PKG_VERSION"),
        total_files
    );
    println!(
        "Settings: MAPQ >= {}  gap_tolerance = {} bp  threshold = {:.0}%  \
         min_reads = {}  min_width = {} bp",
        args.mapq_min,
        args.gap_tolerance,
        args.threshold * 100.0,
        args.min_reads,
        args.min_width,
    );
    println!();

    // ── Configure rayon thread pool ─────────────────────────────────────────
    let threads = if args.threads == 0 {
        rayon::current_num_threads()
    } else {
        rayon::ThreadPoolBuilder::new()
            .num_threads(args.threads)
            .build_global()
            .unwrap_or_else(|e| {
                eprintln!("[warn] could not set thread count: {}", e);
            });
        args.threads
    };
    println!("Using {} thread(s) for parallel file loading.\n", threads);

    // ── Progress bar ────────────────────────────────────────────────────────
    let progress = ProgressBar::new(total_files as u64);
    progress.set_style(
        ProgressStyle::with_template(
            "[{elapsed_precise}] [{bar:40.cyan/blue}] {pos}/{len} files  {msg}"
        )
        .unwrap()
        .progress_chars("=> "),
    );

    // ── Phase 1: parse & merge each file in parallel ────────────────────────
    let t0 = Instant::now();

    // Collect (sample_name, per_chrom_merged_regions) for each file.
    let results: Vec<(String, BTreeMap<String, Vec<MergedRegion>>)> = input_files
        .par_iter()
        .map(|path| {
            let stem = file_stem(path);
            let result = process_one_file(
                path,
                args.mapq_min,
                args.gap_tolerance,
                args.min_reads,
                args.min_width,
                args.verbose,
                &stem,
            );
            progress.inc(1);
            progress.set_message(stem.clone());

            match result {
                Ok(merged) => (stem, merged),
                Err(e) => {
                    eprintln!("[error] skipping {:?}: {}", path, e);
                    (stem, BTreeMap::new())
                }
            }
        })
        .collect();

    progress.finish_with_message("all files parsed");
    println!(
        "\nPhase 1 complete in {:.1}s — {} samples parsed.\n",
        t0.elapsed().as_secs_f64(),
        results.len()
    );

    // Unzip into parallel vecs.
    let (sample_names, all_merged): (Vec<String>, Vec<BTreeMap<String, Vec<MergedRegion>>>) =
        results.into_iter().unzip();

    // ── Phase 2: cross-sample sweep ─────────────────────────────────────────
    let t1 = Instant::now();
    println!("Phase 2: running cross-sample sweep-line (threshold = {:.0}%)…", args.threshold * 100.0);

    let consensus = find_consensus(all_merged, sample_names, args.threshold, total_files);

    println!(
        "Phase 2 complete in {:.1}s — {} consensus region(s) found.\n",
        t1.elapsed().as_secs_f64(),
        consensus.len()
    );

    // ── Phase 3: write output CSV ────────────────────────────────────────────
    let output_path = Path::new(&args.output);
    let rows_written = output::write_csv(&consensus, output_path)?;

    println!(
        "Output written to '{}' ({} rows).",
        args.output, rows_written
    );
    println!(
        "Total wall time: {:.1}s",
        t0.elapsed().as_secs_f64()
    );

    Ok(())
}

// ── Per-file pipeline ────────────────────────────────────────────────────────

/// Parse one TSV file, apply MAPQ filter, then merge intervals per chromosome.
///
/// Returns a `BTreeMap<chrom, Vec<MergedRegion>>` for this sample.
fn process_one_file(
    path:          &Path,
    mapq_min:      u8,
    gap_tolerance: u32,
    min_reads:     u32,
    min_width:     u32,
    verbose:       bool,
    label:         &str,
) -> anyhow::Result<BTreeMap<String, Vec<MergedRegion>>> {
    // Stream parse — never loads the full file into RAM.
    let (chrom_reads, stats) = reader::parse_tsv(path, mapq_min)?;

    if verbose {
        eprintln!(
            "  [{}]  total_reads={:>7}  passing_mapq={:>6}  chroms={}",
            label, stats.total_reads, stats.passing_reads, stats.chroms_seen
        );
    }

    // Merge intervals per chromosome.
    let mut merged_map: BTreeMap<String, Vec<MergedRegion>> = BTreeMap::new();

    for (chrom, reads) in chrom_reads {
        let regions = merge_intervals(&reads, gap_tolerance, min_reads, min_width);
        if !regions.is_empty() {
            if verbose {
                eprintln!(
                    "    └─ {}  {} merged region(s)",
                    chrom, regions.len()
                );
            }
            merged_map.insert(chrom, regions);
        }
    }

    Ok(merged_map)
}

/// Extract filename stem (no extension) from a path for use as sample label.
fn file_stem(path: &Path) -> String {
    path.file_stem()
        .unwrap_or(path.as_os_str())
        .to_string_lossy()
        .into_owned()
}
