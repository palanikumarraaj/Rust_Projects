// args.rs — CLI argument definitions via clap v4 derive macros

use clap::Parser;

/// Cross-sample off-target genomic region consensus finder.
///
/// Loads multiple TSV files (one per BAM sample) produced by off-target
/// analysis pipelines. Each file contains one read per row with columns:
///   chr  start  end  read_id  mapq  orientation  read_length
///
/// For each file the tool:
///   1. Filters reads by MAPQ
///   2. Merges nearby reads into continuous regions
///   3. Identifies regions present in >= threshold fraction of all samples
///
/// Output: CSV of consensus regions with per-region stats.
///
/// Example:
///   offtarget-merge \
///     --input-pattern "data/*_off_model*.tsv" \
///     --mapq-min 20 \
///     --gap-tolerance 500 \
///     --threshold 0.8 \
///     --output consensus_regions.csv
#[derive(Parser, Debug)]
#[command(
    name    = "offtarget-merge",
    version = env!("CARGO_PKG_VERSION"),
    about   = "Find consensus off-target regions across multiple BAM-derived TSV files",
    long_about = None,
)]
pub struct Args {
    /// Glob pattern matching input TSV files.
    /// Example: "data/*_BQSR_bam_off_model*.tsv"
    #[arg(long, short = 'i', value_name = "GLOB")]
    pub input_pattern: String,

    /// Minimum MAPQ score to retain a read.
    /// Reads with MAPQ below this value are discarded before merging.
    /// Note: MAPQ=0 reads (multimappers) make up the majority of off-target
    /// reads — use 0 to include all reads, 20+ for uniquely-mapped only.
    #[arg(long, short = 'q', default_value_t = 20, value_name = "UINT")]
    pub mapq_min: u8,

    /// Maximum gap in bp between two reads still merged into one region.
    /// A value of 500 will bridge a gap up to 500 bp, treating reads on
    /// either side as part of the same continuous off-target region.
    #[arg(long, short = 'g', default_value_t = 500, value_name = "BP")]
    pub gap_tolerance: u32,

    /// Minimum fraction of input files a region must appear in to be reported.
    /// Range: 0.0 – 1.0.  Examples: 0.8 = 80 % of samples, 1.0 = all samples.
    #[arg(long, short = 't', default_value_t = 0.8, value_name = "FLOAT")]
    pub threshold: f64,

    /// Minimum number of reads a merged region must contain (per sample).
    /// Regions with fewer supporting reads in a sample are dropped before
    /// the cross-sample sweep step.
    #[arg(long, default_value_t = 2, value_name = "UINT")]
    pub min_reads: u32,

    /// Minimum width in bp a merged region must span.
    /// Tiny single-read spikes are noisy; this filter removes them.
    #[arg(long, default_value_t = 100, value_name = "BP")]
    pub min_width: u32,

    /// Output CSV file path.
    #[arg(long, short = 'o', default_value = "consensus_regions.csv", value_name = "PATH")]
    pub output: String,

    /// Number of threads for parallel file parsing.
    /// Defaults to the number of logical CPUs on the host machine.
    #[arg(long, default_value_t = 0, value_name = "N")]
    pub threads: usize,

    /// Print per-file statistics after parsing each file.
    #[arg(long, short = 'v')]
    pub verbose: bool,
}
