// output.rs — CSV serialisation of ConsensusRegion results.

use std::path::Path;

use csv::WriterBuilder;
use serde::Serialize;

use crate::sweep::ConsensusRegion;

/// CSV row — mirrors ConsensusRegion with a derived Serialize.
#[derive(Serialize)]
struct CsvRow<'a> {
    chrom:                &'a str,
    region_start:         u32,
    region_end:           u32,
    region_width_bp:      u32,
    sample_count:         usize,
    sample_fraction:      String,   // formatted to 4 decimal places
    contributing_samples: &'a str,
}

/// Write all consensus regions to a CSV file at `output_path`.
///
/// The file will be created (or overwritten). Returns the number of rows written.
pub fn write_csv(
    regions:     &[ConsensusRegion],
    output_path: &Path,
) -> anyhow::Result<usize> {
    let mut wtr = WriterBuilder::new()
        .has_headers(true)
        .from_path(output_path)?;

    for r in regions {
        wtr.serialize(CsvRow {
            chrom:                &r.chrom,
            region_start:         r.region_start,
            region_end:           r.region_end,
            region_width_bp:      r.region_width_bp,
            sample_count:         r.sample_count,
            sample_fraction:      format!("{:.4}", r.sample_fraction),
            contributing_samples: &r.contributing_samples,
        })?;
    }

    wtr.flush()?;
    Ok(regions.len())
}
