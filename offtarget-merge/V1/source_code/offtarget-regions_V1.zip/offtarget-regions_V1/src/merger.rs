// merger.rs — Per-sample interval merge logic.
//
// Takes a sorted slice of (start, end) read intervals from one chromosome
// in one sample, and merges overlapping or near-adjacent intervals into
// larger continuous regions. Applies read-count and width quality filters.

/// A single merged genomic region produced from raw reads within one sample.
#[derive(Debug, Clone)]
pub struct MergedRegion {
    pub start:      u32,
    pub end:        u32,
    pub read_count: u32,
}

impl MergedRegion {
    /// Width of the region in base pairs.
    #[inline]
    pub fn width(&self) -> u32 {
        self.end.saturating_sub(self.start)
    }
}

/// Merge a sorted list of (start, end) read intervals into continuous regions.
///
/// Two intervals are merged when the gap between them is <= `gap_tolerance` bp.
/// After merging, regions with fewer than `min_reads` supporting reads OR
/// narrower than `min_width` bp are dropped.
///
/// The input slice **must be sorted by start** (guaranteed by `reader.rs`).
pub fn merge_intervals(
    sorted_reads:  &[(u32, u32)],
    gap_tolerance: u32,
    min_reads:     u32,
    min_width:     u32,
) -> Vec<MergedRegion> {
    if sorted_reads.is_empty() {
        return Vec::new();
    }

    let mut regions: Vec<MergedRegion> = Vec::new();

    // Initialise with the first read.
    let (mut cur_start, mut cur_end) = sorted_reads[0];
    let mut cur_count: u32 = 1;

    for &(s, e) in &sorted_reads[1..] {
        // Gap check: if this read starts within gap_tolerance of cur_end, extend.
        if s <= cur_end.saturating_add(gap_tolerance) {
            cur_end   = cur_end.max(e);
            cur_count += 1;
        } else {
            // Emit the current region if it passes quality filters.
            let region = MergedRegion {
                start:      cur_start,
                end:        cur_end,
                read_count: cur_count,
            };
            if region.read_count >= min_reads && region.width() >= min_width {
                regions.push(region);
            }

            // Start a fresh region from this read.
            cur_start = s;
            cur_end   = e;
            cur_count = 1;
        }
    }

    // Flush the last open region.
    let region = MergedRegion {
        start:      cur_start,
        end:        cur_end,
        read_count: cur_count,
    };
    if region.read_count >= min_reads && region.width() >= min_width {
        regions.push(region);
    }

    regions
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_basic_merge() {
        // Two overlapping reads should merge into one region.
        let reads = vec![(100u32, 250u32), (200u32, 350u32)];
        let r = merge_intervals(&reads, 0, 1, 1);
        assert_eq!(r.len(), 1);
        assert_eq!(r[0].start, 100);
        assert_eq!(r[0].end,   350);
        assert_eq!(r[0].read_count, 2);
    }

    #[test]
    fn test_gap_tolerance() {
        // 400 bp gap, tolerance=500 → should merge.
        let reads = vec![(100u32, 200u32), (600u32, 750u32)];
        let r = merge_intervals(&reads, 500, 1, 1);
        assert_eq!(r.len(), 1);
        assert_eq!(r[0].start, 100);
        assert_eq!(r[0].end,   750);
    }

    #[test]
    fn test_gap_no_merge() {
        // 600 bp gap, tolerance=500 → should NOT merge.
        let reads = vec![(100u32, 200u32), (801u32, 950u32)];
        let r = merge_intervals(&reads, 500, 1, 1);
        assert_eq!(r.len(), 2);
    }

    #[test]
    fn test_min_reads_filter() {
        // Single-read region with min_reads=2 → dropped.
        let reads = vec![(100u32, 300u32)];
        let r = merge_intervals(&reads, 0, 2, 1);
        assert_eq!(r.len(), 0);
    }

    #[test]
    fn test_chr1_example_region() {
        // Reproduces the chr1:14673-18433 region from the real sample TSV.
        // Key gaps in this cluster (from real data analysis):
        //   14831 -> 15686 = 855 bp gap  (bridged with tol=900)
        //   15837 -> 16571 = 734 bp gap  (bridged with tol=900)
        // gap_tolerance=900 merges the entire cluster into one region.
        let reads = vec![
            (14673u32, 14824u32),
            (14680u32, 14831u32),
            (15686u32, 15837u32),
            (16571u32, 18433u32),
        ];
        let r = merge_intervals(&reads, 900, 2, 100);
        assert_eq!(r.len(), 1, "expected single merged region across chr1 cluster");
        assert_eq!(r[0].start, 14673);
        assert_eq!(r[0].end,   18433);
        assert_eq!(r[0].read_count, 4);
    }

    #[test]
    fn test_chr1_split_at_tight_tolerance() {
        // With gap_tolerance=500:
        //   reads 0+1 overlap  → merged into (14673,14831) with read_count=2  ✓ passes filters
        //   14831 -> 15686 = 855 bp gap → new region (15686,15837) read_count=1 → DROPPED (min_reads=2)
        //   15837 -> 16571 = 734 bp gap → new region (16571,18433) read_count=1 → DROPPED (min_reads=2)
        // So only 1 region survives the min_reads=2 filter.
        let reads = vec![
            (14673u32, 14824u32),
            (14680u32, 14831u32),
            (15686u32, 15837u32),
            (16571u32, 18433u32),
        ];
        let r = merge_intervals(&reads, 500, 2, 100);
        assert_eq!(r.len(), 1, "only the two-read overlap survives min_reads filter");
        assert_eq!(r[0].start, 14673);
        assert_eq!(r[0].end, 14831);
    }
}
