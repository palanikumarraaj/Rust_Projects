// reader.rs — Streaming TSV reader for off-target read files.
//
// Parses one TSV file row-by-row without loading the full file into RAM.
// Returns a BTreeMap<chromosome, sorted Vec<(start, end)>> of reads passing
// the MAPQ filter, ready for interval merging.

use std::collections::BTreeMap;
use std::path::Path;

use csv::ReaderBuilder;
use serde::Deserialize;

/// One row from the input TSV (only the fields we need).
/// `read_id`, `orientation`, and `read_length` are present in the file
/// but not used by the merging algorithm — serde skips them efficiently.
#[derive(Debug, Deserialize)]
struct RawRead {
    #[serde(rename = "chr")]
    chr: String,

    #[serde(rename = "start")]
    start: u32,

    #[serde(rename = "end")]
    end: u32,

    /// Skipped — not needed for region merging.
    #[serde(rename = "read_id")]
    _read_id: String,

    #[serde(rename = "mapq")]
    mapq: u8,

    /// Skipped.
    #[serde(rename = "orientation")]
    _orientation: String,

    /// Skipped.
    #[serde(rename = "read_length")]
    _read_length: u32,
}

/// Statistics collected while parsing one file — used for verbose output.
#[derive(Debug, Default)]
pub struct FileStats {
    pub total_reads:    usize,
    pub passing_reads:  usize,
    pub chroms_seen:    usize,
}

/// Parse a single TSV file and return per-chromosome read coordinate vectors.
///
/// Reads are filtered by `mapq_min`. Each chromosome's Vec is sorted by
/// start position before returning, making it ready for O(n) interval merge.
///
/// Returns `(BTreeMap<chrom, Vec<(start,end)>>, FileStats)`.
pub fn parse_tsv(
    path: &Path,
    mapq_min: u8,
) -> anyhow::Result<(BTreeMap<String, Vec<(u32, u32)>>, FileStats)>
{
    let mut rdr = ReaderBuilder::new()
        .delimiter(b'\t')
        .has_headers(true)
        .flexible(false)           // reject rows with wrong column count
        .from_path(path)?;

    let mut chrom_map: BTreeMap<String, Vec<(u32, u32)>> = BTreeMap::new();
    let mut stats = FileStats::default();

    for result in rdr.deserialize::<RawRead>() {
        // Silently skip malformed rows rather than aborting the whole file.
        let row = match result {
            Ok(r)  => r,
            Err(e) => {
                eprintln!("  [warn] skipping malformed row in {:?}: {}", path, e);
                continue;
            }
        };

        stats.total_reads += 1;

        if row.mapq < mapq_min {
            continue;
        }

        // Sanity-check coordinates (handles any BAM edge cases).
        if row.end <= row.start {
            continue;
        }

        stats.passing_reads += 1;
        chrom_map
            .entry(row.chr)
            .or_default()
            .push((row.start, row.end));
    }

    // Sort each chromosome's reads by start coordinate in-place.
    for reads in chrom_map.values_mut() {
        reads.sort_unstable_by_key(|&(s, _)| s);
    }

    stats.chroms_seen = chrom_map.len();
    Ok((chrom_map, stats))
}
