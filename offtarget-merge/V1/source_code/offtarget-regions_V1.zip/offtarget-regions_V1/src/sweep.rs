// sweep.rs — Cross-sample sweep-line consensus region finder.
//
// Given per-sample merged region lists (all samples, all chromosomes),
// this module finds chromosomal spans where at least `threshold` fraction
// of samples have an overlapping merged region.
//
// Algorithm: coordinate event-sweep (O(N log N) per chromosome).

use std::collections::BTreeMap;

use crate::merger::MergedRegion;

/// A consensus region that passed the cross-sample frequency threshold.
#[derive(Debug, Clone)]
pub struct ConsensusRegion {
    pub chrom:                String,
    pub region_start:         u32,
    pub region_end:           u32,
    pub region_width_bp:      u32,
    pub sample_count:         usize,
    pub sample_fraction:      f64,
    /// Comma-separated list of contributing sample basenames.
    pub contributing_samples: String,
}

/// Event type used in the sweep-line.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
enum EventKind {
    Open  = 0,  // region starts — sort Opens before Closes at same coordinate
    Close = 1,  // region ends + 1
}

#[derive(Debug, Clone)]
struct Event {
    coord:      u32,
    kind:       EventKind,
    sample_idx: usize,
}

/// Run cross-sample sweep on one chromosome.
///
/// `sample_regions`: slice of `(sample_index, &[MergedRegion])` for this chrom.
/// `total_files`: total number of input files (denominator for threshold).
/// `threshold`: minimum required fraction (0.0–1.0).
/// `sample_names`: mapping from sample index to display name (filename stem).
fn sweep_chrom(
    chrom:          &str,
    sample_regions: &[(usize, Vec<MergedRegion>)],
    total_files:    usize,
    threshold:      f64,
    sample_names:   &[String],
) -> Vec<ConsensusRegion> {
    // Build event list.
    let mut events: Vec<Event> = Vec::new();

    for (sample_idx, regions) in sample_regions {
        for r in regions {
            events.push(Event { coord: r.start,     kind: EventKind::Open,  sample_idx: *sample_idx });
            events.push(Event { coord: r.end + 1,   kind: EventKind::Close, sample_idx: *sample_idx });
        }
    }

    // Sort by coordinate; ties: Open before Close (ensures correct boundary handling).
    events.sort_unstable_by(|a, b| {
        a.coord.cmp(&b.coord).then(a.kind.cmp(&b.kind))
    });

    let min_samples = (threshold * total_files as f64).ceil() as usize;

    // Sweep.
    let mut active: ahash::AHashSet<usize> = ahash::AHashSet::default();
    let mut in_span = false;
    let mut span_start: u32 = 0;
    let mut span_samples: ahash::AHashSet<usize> = ahash::AHashSet::default();

    let mut consensus: Vec<ConsensusRegion> = Vec::new();

    // Group events at the same coordinate so we process them atomically.
    let mut i = 0;
    while i < events.len() {
        let coord = events[i].coord;

        // Process all events at `coord`.
        let mut j = i;
        while j < events.len() && events[j].coord == coord {
            match events[j].kind {
                EventKind::Open  => { active.insert(events[j].sample_idx); }
                EventKind::Close => { active.remove(&events[j].sample_idx); }
            }
            j += 1;
        }

        let active_count = active.len();
        let fraction     = active_count as f64 / total_files as f64;

        if !in_span && fraction >= threshold as f64 && active_count >= min_samples {
            // Enter qualifying span.
            in_span       = true;
            span_start    = coord;
            span_samples  = active.clone();
        } else if in_span {
            if fraction < threshold as f64 || active_count < min_samples {
                // Exit qualifying span — emit region.
                let span_end = coord.saturating_sub(1);
                if span_end >= span_start {
                    consensus.push(build_region(
                        chrom, span_start, span_end,
                        &span_samples, total_files, sample_names,
                    ));
                }
                in_span = false;
                span_samples.clear();
            } else {
                // Still in span — union the contributing samples.
                for &s in &active {
                    span_samples.insert(s);
                }
            }
        }

        i = j;
    }

    // Flush any open span at end of events.
    if in_span && !span_samples.is_empty() {
        // Find the maximum end coordinate of contributing samples.
        let span_end = sample_regions
            .iter()
            .filter(|(idx, _)| span_samples.contains(idx))
            .flat_map(|(_, regions)| regions.iter().map(|r| r.end))
            .max()
            .unwrap_or(span_start);

        consensus.push(build_region(
            chrom, span_start, span_end,
            &span_samples, total_files, sample_names,
        ));
    }

    consensus
}

/// Construct a ConsensusRegion from sweep-line output.
fn build_region(
    chrom:        &str,
    start:        u32,
    end:          u32,
    samples:      &ahash::AHashSet<usize>,
    total_files:  usize,
    sample_names: &[String],
) -> ConsensusRegion {
    let mut names: Vec<&str> = samples
        .iter()
        .map(|&i| sample_names[i].as_str())
        .collect();
    names.sort_unstable();

    ConsensusRegion {
        chrom:                chrom.to_string(),
        region_start:         start,
        region_end:           end,
        region_width_bp:      end.saturating_sub(start),
        sample_count:         samples.len(),
        sample_fraction:      samples.len() as f64 / total_files as f64,
        contributing_samples: names.join(","),
    }
}

/// Entry point: run the cross-sample sweep across all chromosomes.
///
/// `all_sample_regions`: Vec indexed by sample — each entry is a
/// `BTreeMap<chrom, Vec<MergedRegion>>`.
/// `sample_names`: display name (filename stem) for each sample index.
/// `threshold`: fraction of files required (0.0–1.0).
pub fn find_consensus(
    all_sample_regions: Vec<BTreeMap<String, Vec<MergedRegion>>>,
    sample_names:       Vec<String>,
    threshold:          f64,
    total_files:        usize,
) -> Vec<ConsensusRegion> {
    // Collect all unique chromosomes.
    let mut all_chroms: std::collections::BTreeSet<String> = std::collections::BTreeSet::new();
    for sample in &all_sample_regions {
        for chrom in sample.keys() {
            all_chroms.insert(chrom.clone());
        }
    }

    // For each chrom, collect (sample_idx, regions) pairs.
    let mut all_consensus: Vec<ConsensusRegion> = Vec::new();

    for chrom in &all_chroms {
        let mut sample_regions: Vec<(usize, Vec<MergedRegion>)> = Vec::new();

        for (sample_idx, sample_map) in all_sample_regions.iter().enumerate() {
            if let Some(regions) = sample_map.get(chrom) {
                if !regions.is_empty() {
                    sample_regions.push((sample_idx, regions.clone()));
                }
            }
        }

        if sample_regions.is_empty() {
            continue;
        }

        let mut chrom_results = sweep_chrom(
            chrom,
            &sample_regions,
            total_files,
            threshold,
            &sample_names,
        );

        all_consensus.append(&mut chrom_results);
    }

    // Sort output by natural chrom order, then region_start.
    all_consensus.sort_by(|a, b| {
        chrom_sort_key(&a.chrom)
            .cmp(&chrom_sort_key(&b.chrom))
            .then(a.region_start.cmp(&b.region_start))
    });

    all_consensus
}

/// Natural sort key for chromosome names.
/// chr1 < chr2 < ... < chr10 < chrX < chrY < chrM < anything else.
fn chrom_sort_key(chrom: &str) -> (u8, u32, String) {
    let name = chrom.strip_prefix("chr").unwrap_or(chrom);
    match name {
        "X" => (1, 0, String::new()),
        "Y" => (1, 1, String::new()),
        "M" | "MT" => (1, 2, String::new()),
        _ => match name.parse::<u32>() {
            Ok(n) => (0, n, String::new()),
            Err(_) => (2, 0, name.to_string()),
        },
    }
}
